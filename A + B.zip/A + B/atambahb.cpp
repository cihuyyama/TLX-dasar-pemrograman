#include <iostream>
using namespace std;

int main(){
	int x, y, jumlah;
	cin >> x >> y;
	jumlah = x+y;
	cout << jumlah << endl;
}
